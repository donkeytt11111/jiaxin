import logging
from logging import handlers
from selenium import webdriver
from time import sleep

def get_alert_msg():
    sleep(1)
    msg = BaseDriver.get_driver().find_element('xpath','/html').text
    return msg

class BaseDriver(object):
    __driver = None
    @classmethod
    def get_driver(cls):
        if cls.__driver is None:
            cls.__driver = webdriver.Chrome()
            cls.__driver.maximize_window()
            cls.__driver.implicitly_wait(10)
        return cls.__driver
    # @classmethod
    # def quit_driver(cls):
    #     if cls.__driver:
    #         sleep(3)
    #         cls.__driver.quit()
    #         cls.__driver = None

    @classmethod
    def back_bt(cls):
        cls.__driver.back()

if __name__ == '__main__':
    BaseDriver.get_driver()
    sleep(2)

