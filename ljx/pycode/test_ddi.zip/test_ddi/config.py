# config.py
BASE_URL = 'http://172.16.102.193:32003/'