import pytest
from time import sleep
from utils import BaseDriver, get_alert_msg
from page_ddi.page_test_ddi import DdiTask
from config import BASE_URL




class TestIndex(object):
    def setup_class(self):
        self.driver = BaseDriver.get_driver()
        self.ddi_task = DdiTask()
        self.driver.get(BASE_URL)
    # def setup_method(self):
    #     self.driver.get('http://172.16.102.193:32003/')
    # def teardown_class(self):
    #     BaseDriver.quit_driver()
    def test01_ddi_login(self):
        self.ddi_task.go_to_ddi('admin','Passw0rd@MY')
        sleep(2)
        msg = get_alert_msg()
        # log.logger.info("测试完成\n" +  msg)
        print("错误信息" + msg)
    def test02_ddi_site(self):
        self.ddi_task.go_to_new_domain(BASE_URL + '/dcim/sites/')
        self.ddi_task.go_to_add_site('Mingyang', 'Mingyang')

    def test03_ddi_device(self):
        self.ddi_task.go_to_device_url(BASE_URL + '/dcim/device-roles/add/')
        self.ddi_task.go_to_add_device('接入设备', 'access-device')
        self.ddi_task.go_to_device_url(BASE_URL +  '/dcim/device-roles/add/')
        self.ddi_task.go_to_add_device('核心设备', 'core-device')
        self.ddi_task.go_to_device_url(BASE_URL + '/dcim/device-roles/add/')
        self.ddi_task.go_to_add_device('终端', 'terminal')

    def test04_ddi_alltype(self):
        self.ddi_task.go_to_manufacturer_url(BASE_URL + '/dcim/manufacturers/add')
        self.ddi_task.go_to_add_manufacturer('Mingyang', 'Mingyang')
        self.ddi_task.go_to_Module_url(BASE_URL + '/dcim/module-types/add/')
        self.ddi_task.go_to_add_Module('Mingyang')
        self.ddi_task.go_to_DeviceTypes_url(BASE_URL + '/dcim/device-types/add/')
        self.ddi_task.go_to_add_DeviceTypes('Mingyang', 'Mingyang')

if __name__ == '__main__':
    pytest.main(['-s', 'test_ddi.py'])