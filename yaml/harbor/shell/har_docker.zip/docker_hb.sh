#!/bin/bash
###使用docker从镜像文件中下载镜像——将下载的镜像进行打包保存——删除下载到本地的镜像——将封装好的镜像包移动到备份目录
Image_tags=$(uniq $Images_File)
for image_tag in $Image_tags;do
    image_Name=$(echo $image_tag | awk -F/ '{print $3}' |  awk -F: '{print $1}')
    image_Lable=$(echo $image_tag | awk -F/ '{print $3}' |  awk -F: '{print $2}')
    docker pull $image_tag
    docker save $image_tag  -o $image_Name-$image_Lable.tar
    docker rmi  $image_tag
    mv $image_Name-$image_Lable.tar  $Tar_File
done
